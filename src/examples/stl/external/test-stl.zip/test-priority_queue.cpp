/*
 *  Test rig to play  with priority_queues.   See Schildt  PP 830
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <queue>
#include <functional>
#include <vector>

using namespace std;

int main(){

  // priority_queue<int> q;   // has no iterator

  priority_queue<int, vector<int>, greater<int> > q;
     // by default  vector is  used as container
     // by default  less is  used as comparator

  for(int i=0; i < 6 ;i++){
    q.push(i);
  }

  cout << "Queue size " << q.size() << endl;
  cout << "Queue empty ? " << boolalpha << q.empty() << endl;

  cout << "Priority element is " << q.top() << endl;

  cout << "Queue priority elements, in order, are:";
  while( !q.empty() ){
    cout << " " << q.top();

    q.pop();  // discards head of queue

  } cout << endl;

  cout << "Queue size " << q.size() << endl;

}

