/*
 *  Test rig   to play  with maps.   See Schildt  PP 658  and 822
 *
 *  Last Modified, 22.9.03, KAH
 *
 */
#include <iostream>
#include <string>
#include <map>

using namespace std;

int main(){

  map<int,int> mapping;       // parameterised by key, value
  map<int,int>::iterator it;  // map iterators  are  pairs  of  key,value
  map<int,int>::iterator it1;


  for(int i=0;i<5;i++){
    mapping.insert(make_pair( i, i* 10 ) );
    cout << "Put " << i << " in" << endl;
  }

  for(int i=5;i<10;i++){
    mapping.insert(pair<int,int>( i, i*10) );
    cout << "Put " << i << " in" << endl;
  }

  mapping[10] =100;
  cout << "Put " << 10 << " in" << endl;

  cout << endl;


  cout << "Size: " << mapping.size() << endl << endl;


  for(int i=0;i<10;i++){
    it = mapping.find(i);
    cout << "Found " << it->second << " keyed by " << it->first << endl;
  }
  cout << endl;

  it = mapping.begin();
  mapping.erase( it );

  it = mapping.begin();
  it1 = ++it;  it1++;
  mapping.erase( it, it1 );

  if( !mapping.empty() ){
    for(it=mapping.begin();it!=mapping.end();it++){
      cout << "Found " << it->second << " keyed by " << it->first << endl;
  
    }
  }

  map<int,int> mapping2;       //   key, value
  mapping2[11] = 110;

  // sadly this  does not  work
  // mapping += mapping2;

  cout << endl;
  for(int i=0;i<10;i++){
    cout << "Key  " << i  << " has " << mapping.count(i) << " entries."<< endl;
  }



  mapping.clear();


  cout << endl << endl;

  map<string,int> m1, m2;
  map<string,int>::iterator  iter;  // points to a pair<string,int>

  string one("One");
  string two("Two");
  string three("Three");
  string four("Four");
  string five("Five");

  m1[one]   = 1;
  m2[two]   = 2;
  m1[three] = 3;
  m2[four]  = 4;
  m1[five]  = 5;

  for(iter=m1.begin();iter!=m1.end();iter++){
    cout << "Found " << iter->second << " keyed by " << iter->first << endl;
  } cout << endl;

  m1.swap(m2);

  for(iter=m1.begin();iter!=m1.end();iter++){
    cout << "Found " << iter->second << " keyed by " << iter->first << endl;
  }

}
