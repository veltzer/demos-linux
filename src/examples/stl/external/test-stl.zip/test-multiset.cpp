/*
 *  Test rig to play  with multisets.   See Schildt  PP 827
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <string>
#include <set>

using namespace std;

int main(){

  multiset<int> ms;
  multiset<int>::iterator  iter;  // points to a pair<string,int>

  ms.insert( ms.end(), 1 );  // cannot use [] notation
  ms.insert( ms.end(), 3);
  ms.insert( ms.end(), 2);
  ms.insert( ms.end(), 4);
  ms.insert( ms.end(), 4);
  ms.insert( ms.end(), 5);

  cout << "Multiset contains: ";
  for(iter=ms.begin();iter!=ms.end();iter++){
    cout << " " << *iter;
  } cout << endl;

  iter = ms.find(3); 
  cout << "Found " << *iter++ << " followed by " << *iter << endl;

  iter = ms.find(4); 
  cout << "Found " << *iter++ << " followed by " << *iter << endl;

  ms.erase(iter);

  cout << "Multiset now contains: ";
  for(iter=ms.begin();iter!=ms.end();iter++){
    cout << " " << *iter;
  } cout << endl;

}
