/*
 *  Test rig to play  with sets.   See Schildt  PP 831
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <string>
#include <set>

using namespace std;

int main(){

  set<int> s1, s2, s3;
  set<int>::iterator it;
  
  for(int i=9;i>=0;i--){
    if( i%2 )
      s1.insert(s1.begin(), i);
    else
      s2.insert(s2.end(), i);
  }
  cout << "size of s1 is " << s1.size() << endl;    

  cout << "size of s2 is " << s2.size() << endl;    

  cout << "s1 contains";
  for(it=s1.begin();it != s1.end(); it++){
    cout << " " << *it;
  } cout << endl;

  cout << "s2 contains";
  for(it=s2.begin();it != s2.end(); it++){
    cout << " " << *it;
  } cout << endl;

  s3 = s1;
  s3.insert( s2.begin(), s2.end() );

  cout << "s3 contains";
  for(it=s3.begin();it != s3.end(); it++){
    cout << " " << *it;
  } cout << endl;

  if( s3.find(4) != s3.end() )
    cout << "s3 contains  4" << endl;
  else
    cout << "s3 does not contain 4" << endl;

  if( s3.find(11) != s3.end() )
    cout << "s3 contains  11" << endl;
  else
    cout << "s3 does not contain 11" << endl;

}
