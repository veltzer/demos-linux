/*
 *  Test rig to play  with multimaps.   See Schildt  PP 824
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <string>
#include <map>

using namespace std;

int main(){


  multimap<string,int> m1, m2;
  multimap<string,int>::iterator  iter;  // points to a pair<string,int>

  string one("One");  string two("Two");  string three("Three");
  string four("Four");string five("Five");string six("Six");

  m1.insert( m1.end(), make_pair(one, 1) );  // cannot use [] notation
  m1.insert( m1.end(), make_pair(two, 2) );
  m1.insert( m1.end(), make_pair(three, 3) );
  m1.insert( m1.end(), make_pair(four, 4) );
  m1.insert( m1.end(), make_pair(five, 5) );

  m1.insert( m1.begin(), make_pair(six, 6) );

  m1.insert( m1.begin(), make_pair(four, 40) );

  for(iter=m1.begin();iter!=m1.end();iter++){
    cout << "Found " << iter->second << " keyed by " << iter->first << endl;
  } cout << endl;

  m1.swap(m2);

  for(iter=m1.begin();iter!=m1.end();iter++){
    cout << "Found " << iter->second << " keyed by " << iter->first << endl;
  }

}
