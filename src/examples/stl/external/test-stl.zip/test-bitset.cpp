#include <iostream>
#include <bitset>

using namespace std;

int main(){
  const int N = 24;
  bitset<N> bs;
  bs.reset();
  bs.set(1); bs.set(2);  bs.set(4); bs.set(8);
  cout << bs[8] << endl;
  for(int i=N-1;i>=0;i--){
    cout << bs.test(i);
    if (! ( i%8 ) ) cout << " ";
  } cout << endl;

  bs <<= 2 ;
  for(int i=N-1;i>=0;i--){
    cout << bs.test(i);
    if (! ( i%8 ) ) cout << " ";
  }  cout << endl;

  bs >>= 2 ;
  for(int i=N-1;i>=0;i--){
    cout << bs.test(i);
    if (! ( i%8 ) ) cout << " ";
  }  cout << endl;


}
