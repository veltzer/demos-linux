/*
 *  Test rig to play  with stacks.   See Schildt  PP 833
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <stack>

using namespace std;

int main(){

  stack<int> s;   // has no iterator

  cout << "Pushing onto stack: ";
  for(int i=0; i < 6 ;i++){
    cout << " " << i;
    s.push(i);
  }
  for(int i=12; i >= 6 ;i--){
    cout << " " << i;
    s.push(i);
  }
  cout << endl;

  cout << "Stack size " << s.size() << endl;

  cout << "    Top of stack is:";
  while( !s.empty() ){
    cout << " " << s.top();

    s.pop();  // discards top of stack

  } cout << endl;

  cout << "Stack size " << s.size() << endl;

}
