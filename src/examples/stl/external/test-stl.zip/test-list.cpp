#include <iostream>
#include <list>

using namespace std;

bool isOdd( int i ){
  return i%2;
}

int main(){

  list<int> l1, l2;

  l1.push_front(2);l1.push_front(4);l1.push_front(6);l1.push_front(8);

  l2.push_back( 1 );
  l2.push_back( 3 );
  l2.push_back( 5 );
  l2.push_back( 7 );

  for(list<int>::iterator it = l1.begin(); it != l1.end(); it++){
    cout << *it << " ";
  } cout << endl;

  l1.sort();

  for(list<int>::iterator it = l1.begin(); it != l1.end(); it++){
    cout << *it << " ";
  } cout << endl;

  for(list<int>::iterator it = l2.begin(); it != l2.end(); it++){
    cout << *it << " ";
  } cout << endl;

  l1.merge( l2 );

  for(list<int>::iterator it = l1.begin(); it != l1.end(); it++){
    cout << *it << " ";
  } cout << endl;

  l1.reverse();

  cout << boolalpha << isOdd( 2 ) << endl;

  l1.remove_if( isOdd );

  for(list<int>::iterator it = l1.begin(); it != l1.end(); it++){
    cout << *it << " ";
  } cout << endl;

}

