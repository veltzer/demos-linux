#include <iostream>
#include <deque>

using namespace std;

int main(){

  deque<int> dq;

  dq.push_back( 4 );
  dq.push_back( 5 );
  dq.push_front( 3 );
  dq.push_front( 2 );
  dq.push_front( 1 );
  cout << "Max  size of  deque is " << dq.max_size() << endl;

  cout << "Element 2 is " << dq[2] << endl;

  cout << "Back Element is " << dq.back() << endl;
  
  for(deque<int>::iterator it=dq.begin();it!=dq.end();it++){
    cout << *it << " ";
  } cout << endl;

  deque<int>::iterator it=dq.begin();
  it += 3;
  dq.erase( it );

  for(deque<int>::reverse_iterator rit=dq.rbegin();rit!=dq.rend();rit++){
    cout << *rit << " ";
  } cout << endl;

  deque<int> dq2;
  dq2.push_front( 30 );
  dq2.push_front( 20 );
  dq2.push_front( 10 );

  dq.swap( dq2 );
  for(deque<int>::iterator it=dq.begin();it!=dq.end();it++){
    cout << *it << " ";
  } cout << endl;

  dq2.assign( 3, 8 );

  for(deque<int>::iterator it=dq2.begin();it!=dq2.end();it++){
    cout << *it << " ";
  } cout << endl;

}
