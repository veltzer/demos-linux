/*
 *  Test rig to play  with queues.   See Schildt  PP 829
 *
 *  Last Modified, 24.9.03, KAH
 *
 */
#include <iostream>
#include <string>
#include <queue>

using namespace std;

int main(){

  queue<int> q;   // has no iterator

  for(int i=0; i < 6 ;i++){
    q.push(i);
  }

  cout << "Queue size " << q.size() << endl;
  cout << "Queue empty ? " << boolalpha << q.empty() << endl;

  cout << "Queue contains:";
  while( !q.empty() ){
    cout << " " << q.front();

    q.pop();  // discards head of queue

  } cout << endl;

  cout << "Queue size " << q.size() << endl;

}
