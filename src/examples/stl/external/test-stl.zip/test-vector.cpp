#include <iostream>
#include <vector>

using namespace std;

int main(){

  vector<int> v;
  vector<int>::iterator it, start, end;

  for(int i=0;i<10;i++){
    v.push_back(i);
  }

  cout << "v size = " << v.size() << endl;

  start = v.begin();
  start += 3;   // now points  at element [3]

  end = start;
  end += 4;     // now points  at  element [7]

  v.erase(start, end );  // erases 3,4,5,6

  cout << "v size = " << v.size() << endl;

  for(it=v.begin();it<v.end();it++){
    *it *= 10;
  }

  cout  << "v contains: ";
  for(int i=0;i<v.size(); i++){
    cout << " " << v[i];
  } cout << endl;


}
