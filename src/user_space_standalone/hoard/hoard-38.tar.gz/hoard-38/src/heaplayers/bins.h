#ifndef _BINS_H_
#define _BINS_H_

namespace HL {

  template <class Header, int Size>
    class bins;

}


#endif
